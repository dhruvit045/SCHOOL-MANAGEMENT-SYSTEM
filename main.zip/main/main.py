
from flask import Flask,render_template,request,redirect,session, url_for 
import mysql.connector

app = Flask(__name__)
app.secret_key = "brother"


db = mysql.connector.connect(
    host = "localhost",
    user = "root",
    password = "30062007",
    database = "college_manage"
)

mycursor = db.cursor(dictionary=True , buffered=True)

# MAIN_DASHBOARD PAGE ALL ROUTES HOME , ACADEMIC , ABOUT , ADMISSION , CONTACT AND LOGIN

@app.route('/')
def home():
    
    return render_template('main_dashboard.html')

@app.route('/academic')
def academic():
    return render_template('academic.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/admission',methods=['GET','POST'])
def admission():
    course_query = "SELECT * FROM COURSES ;"
    mycursor.execute(course_query)
    course = mycursor.fetchall()
    print(course)
    if request.method == 'POST':
        name = request.form['name']
        dob = request.form['dob']
        email = request.form['email']
        mobil_no = request.form['mobil_no']
        course = request.form['course']
        address = request.form['address']

        query = "INSERT INTO ADMISSION (FULL_NAME , DATE_OF_BIRTH , EMAIL , PHONE_NO ,COURSE , ADDRESS) VALUES (%s,%s,%s,%s,%s,%s);"
        val = (name,dob,email,mobil_no,course,address)

        mycursor.execute(query,val)
        db.commit()

    return render_template('admission.html',course=course)

@app.route('/view_admission')
def view_admission():

    if session.get("role") != "admin":
        return "Access Denied"

    user_id  = session.get("username")

    mycursor.execute("SELECT * FROM ADMISSION")
    data = mycursor.fetchall()

    return render_template(
        'admin/view_admissions.html',
        admissions=data,
        user_id=user_id
)

@app.route('/admin/delete_admission/<int:id>')
def delete_admission(id):

    mycursor.execute(
        "DELETE FROM ADMISSION WHERE ID=%s",
        (id,)
    )
    db.commit()

    return redirect(url_for('view_admission')
)


@app.route('/contact',methods=['GET','POST'])
def contact():
    if request.method == 'POST' :
        name = request.form['name']
        email = request.form['email']
        subject = request.form['subject']
        mobil_no = request.form['mobil_no']
        message = request.form['message']
        
        sql_query = "INSERT INTO CONTACTS (FULL_NAME , EMAIL , SUBJECT , PHONE_NO , MESSAGE ) VALUES (%s,%s,%s,%s,%s);"
        val = (name,email,subject,mobil_no,message)

        mycursor.execute(sql_query,val)
        db.commit()
        
    return render_template('contact.html')

@app.route('/view_contact')
def contact_details():

    user_id  = session.get("username")
    if session.get("role") != "admin":
        return "Access Denied"

    mycursor.execute("SELECT * FROM CONTACTS")
    contacts = mycursor.fetchall()

    return render_template(
        'admin/view_contact.html',
        contacts=contacts,
        user_id=user_id
    )

@app.route('/admin/delete_record/<int:id>')
def delete_record(id):
    mycursor.execute("DELETE FROM CONTACTS WHERE ID=%s",(id,))
    db.commit()
    return redirect(url_for('contact_details'))


@app.route('/login',methods=['GET','POST'])
def login():

    if request.method == 'POST' :
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')
        session["role"] = role
        

        if role == 'admin':

            login_query = "SELECT * FROM ADMIN WHERE USERNAME = %s and PASSWORD = %s AND ROLE = %s;"
            val = (username,password,role)
            mycursor.execute(login_query,val)
            user = mycursor.fetchone()
            # print(user)
            if user :
                session['username'] = user['USERNAME']
                # print(session['username'])
                return redirect('/admin/admin_dashboard')
        
        elif role == 'student' :
            
            std = "SELECT * FROM students WHERE ID = %s AND phone_number = %s;"
            val_std = (username,password)
            mycursor.execute(std,val_std)

            user = mycursor.fetchone()         

            # print(user)
            if user :
                session['student_id'] = user['id']
                session['firstname'] = user['Firstname']
                session['course'] = user['course'] 
           
                return redirect('/student')
        
        elif role == 'teacher' :

            teacher = "SELECT * FROM teachers WHERE ID = %s AND MOBIL_NO = %s;"
            val_teacher = (username,password)
            mycursor.execute(teacher,val_teacher)
            
            user = mycursor.fetchone()
            # print(user)
            if user :
                session['teacher_id'] = user['ID']
                session['firstname'] = user['FIRSTNAME']
                # print(session['firstname'])
                return redirect('/teacher')
        else :
            print("invalid role")
            return redirect('/login')

    return render_template('login.html')
            

@app.route('/logout')
def logout():
    session.clear()
    
    return redirect('/login')

# ADMIN  ALL PAGES  

@app.route('/admin/admin_dashboard')
def admin():
    if session.get("role") != "admin" :
        return "access denied"
    
    user_id  = session.get("username")
    # print(session.get("username"))
    # firstname = session.get('firstname')

    query = "SELECT * FROM admin WHERE USERNAME = %s;"

    count_student = "SELECT COUNT(*) FROM students;"
    count_teacher = "SELECT COUNT(*) FROM teachers;" 
    count_class = "SELECT COUNT(*) FROM COURSES"
    mycursor.execute(count_student)
    s_count = mycursor.fetchone()
    
    
    mycursor.execute(count_teacher)
    t_count = mycursor.fetchone()
    
    mycursor.execute(count_class)
    c_count = mycursor.fetchone()

    mycursor.execute("SELECT * FROM NOTICE ORDER BY created_at DESC")
    notice = mycursor.fetchall()

    val = (user_id,)
    mycursor.execute(query, val)
    admin = mycursor.fetchone()

    return render_template('admin/admin_dashboard.html',admin=admin,s_count = s_count,t_count=t_count,c_count=c_count,notice=notice,user_id=user_id)


@app.route('/admin/admin_students',methods=['GET','POST'])
def admin_students():

    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("username")

    course_query = "SELECT * FROM COURSES ;"
    mycursor.execute(course_query)
    course = mycursor.fetchall()
    # print(course)

    if request.method == 'POST' :

        student_id = request.form.get('id') 

        firstname = request.form['firstname']
        middlename = request.form['middlename']
        surname = request.form['surname']
        dob = request.form['dob']
        gender = request.form['gender']
        admission_no = request.form['admission-no']
        roll_no = request.form['roll-no']
        aadhar_no = request.form['aadhar-no']
        mobil_no = request.form['mobil_no']
        email = request.form['email']
        category = request.form['category']
        religion = request.form['religion']
        nationality = request.form['nationality']
        course = request.form['course'] 
        address = request.form['address']
        city = request.form['city']
        state = request.form['state']
        pincode = request.form['pincode']
        parent_name = request.form['parent_name']
        parent_contact_no = request.form['parent_contact_no']
        parent_email = request.form['parent_email']

        if student_id :
            query_update = "UPDATE students SET FIRSTNAME=%s, MIDDLENAME=%s, SURNAME=%s, DOB=%s, GENDER=%s, ADMISSION_NO=%s, ROLL_NUMBER=%s, AADHAR_NUMBER=%s, PHONE_NUMBER=%s, EMAIL=%s, CATEGORY=%s, RELIGION=%s, NATIONALITY=%s, COURSE=%s , ADDRESS=%s, CITY=%s, STATE=%s, PINCODE=%s, PARENT_NAME=%s, PARENT_PHONE=%s, PARENT_EMAIL=%s WHERE id=%s"
            val = (firstname, middlename, surname, dob, gender, admission_no, roll_no, aadhar_no, mobil_no, email, category, religion, nationality, course, address, city, state, pincode, parent_name, parent_contact_no, parent_email,student_id)

            mycursor.execute(query_update,val)


        else :
            query_insert = "INSERT INTO students (FIRSTNAME , MIDDLENAME , SURNAME ,DOB , GENDER , ADMISSION_NO, ROLL_NUMBER, AADHAR_NUMBER , PHONE_NUMBER , EMAIL , CATEGORY, RELIGION, NATIONALITY, COURSE  , ADDRESS , CITY , STATE , PINCODE , PARENT_NAME , PARENT_PHONE , PARENT_EMAIL) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);"
            val = (firstname,middlename,surname,dob,gender,admission_no,roll_no,aadhar_no,mobil_no,email,category,religion,nationality,course,address,city,state,pincode,parent_name,parent_contact_no,parent_email)

            mycursor.execute(query_insert,val)


        db.commit()
        
    show_query = "SELECT * FROM students "
    mycursor.execute(show_query)
    result = mycursor.fetchall()
    # print(result)    
    return render_template('admin/admin_students.html',result=result,courses=course,admin=admin,user_id=user_id)

@app.route('/admin/show_student/<int:id>')
def show_student(id):

    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("username")

    mycursor.execute("SELECT * FROM students WHERE id = %s", (id,))
    student = mycursor.fetchone()

    # print(student)
    return render_template('admin/show_student.html', student=student, admin=admin,user_id=user_id)

@app.route('/admin/edit_student/<int:id>', methods=['GET', 'POST'])
def edit_student(id):
    
    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("student_id")

    course_query = "SELECT * FROM COURSES ;"
    mycursor.execute(course_query)
    course = mycursor.fetchall()
    
    mycursor.execute("SELECT * FROM students WHERE id=%s", (id,))
    students = mycursor.fetchone()
    # print(students)

    mycursor.execute("SELECT * FROM students")
    result = mycursor.fetchall()

    
    return render_template('/admin/admin_students.html',courses=course,result=result,admin=admin,student=students,user_id=user_id)

@app.route('/admin/delete_student/<int:id>')
def delete_student(id):

    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("username")

    mycursor.execute("DELETE FROM students WHERE id=%s", (id,))
    db.commit()
    # return redirect(url_for('admin_students'))

    return render_template('/admin/admin_students.html',admin=admin,user_id=user_id)

@app.route('/admin/admin_teachers', methods=['GET', 'POST'])
def admin_teachers():

    if session.get("role") != "admin" :
        return "access denied"
    
    user_id  = session.get("username")

    course_query = "SELECT * FROM COURSES ;"
    mycursor.execute(course_query)
    course = mycursor.fetchall()
    
    if request.method == 'POST':

        teacher_id = request.form.get('id')                      

        firstname = request.form['firstname']       
        middlename = request.form['middlename']
        surname = request.form['surname']
        gender = request.form['gender']
        dob = request.form['dob']
        join_date = request.form['join_date']
        subject = request.form['subject']
        mobil_no = request.form['mobil_no']
        email = request.form['email']
        address = request.form['address']


        if teacher_id: 

            query = "UPDATE teachers SET FIRSTNAME=%s,MIDDLENAME=%s,SURNAME=%s,GENDER=%s,DOB=%s,JOIN_DATE=%s,SUBJECT=%s,MOBIL_NO=%s,EMAIL=%s,ADDRESS=%s WHERE id=%s;"

            val = (firstname,middlename,surname , gender, dob, join_date,subject,mobil_no, email, address,teacher_id)

        else: 

            query = "INSERT INTO teachers (FIRSTNAME,MIDDLENAME,SURNAME,GENDER,DOB,JOIN_DATE,SUBJECT,MOBIL_NO,EMAIL,ADDRESS) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);"

            val = (firstname,middlename,surname, gender, dob, join_date,subject,mobil_no, email, address)

        mycursor.execute(query, val)
        db.commit()

        
    show_query = "SELECT * FROM teachers "
    mycursor.execute(show_query)
    result = mycursor.fetchall()
    
    return render_template('admin/admin_teachers.html',course=course,admin=admin,result=result,user_id=user_id)

@app.route('/admin/edit_teacher/<int:id>',methods=['GET','POST'])
def edit_teachers(id):
    if session.get("role") != "admin" :
        return "access denied"
    
    user_id  = session.get("username")

    course_query = "SELECT * FROM COURSES ;"
    mycursor.execute(course_query)
    course = mycursor.fetchall()
 
    mycursor.execute("SELECT * FROM teachers WHERE id=%s", (id,))
    teacher = mycursor.fetchone()
    # print(teacher)

    mycursor.execute("SELECT * FROM teachers")
    result = mycursor.fetchall()
    # return redirect(url_for('admin_teachers'))


    return render_template('admin/admin_teachers.html',course=course,user_id=user_id,teacher=teacher,result=result,admin=admin)

@app.route('/admin/delete_teachers/<int:id>')
def delete_teacher(id):
    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("username")

    mycursor.execute("DELETE FROM teachers WHERE id=%s", (id,))
    db.commit()

    return render_template('/admin/admin_teachers.html',admin=admin,user_id=user_id)


@app.route('/admin/admin_courses', methods=['GET', 'POST'])
def admin_courses():
    
    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("username")

    if request.method == 'POST' :
        course_name = request.form['c_name']
        course_code = request.form['c_code']
        department = request.form['department']
        credits = request.form['credits']

        query = "INSERT INTO COURSES (COURSE_NAME,COURSE_CODE,DEPARTMENT,CREDITS) VALUES(%s,%s,%s,%s)"
        val = (course_name,course_code,department,credits)
        mycursor.execute(query,val)
        db.commit()
        return redirect(url_for('admin_courses'))
    
    show_query = "SELECT * FROM courses "
    
    mycursor.execute(show_query)
    courses = mycursor.fetchall()
    # print(courses)

    return render_template('admin/admin_courses.html', courses=courses,admin=admin,user_id=user_id)

@app.route('/admin/delete_course/<int:id>')
def delete_course(id):
    if session.get("role") != "admin" :
            return "access denied"
    
    user_id  = session.get("username")

    mycursor.execute("DELETE FROM COURSES WHERE id=%s", (id,))
    db.commit()

    return render_template('admin/admin_courses.html',admin=admin,user_id=user_id)
    

@app.route('/admin/exam', methods=['GET', 'POST'])
def admin_exam():

    if session.get("role") != "admin" : 
        return "access denied"

    user_id  = session.get("username")

    course_query = "SELECT * FROM COURSES ;"
    mycursor.execute(course_query)
    course = mycursor.fetchall()

    if request.method == 'POST':
        if 'addexam' in request.form:
            exam_name = request.form['exam-name']
            course = request.form['course']
            academic_year = request.form['academic-year']
            exam_type = request.form['exam-type']

            
            query_insert = "INSERT INTO exam (exam_name ,course , academic_year , EXAM_TYPE) VALUES (%s,%s,%s,%s);"
            val = (exam_name,course,academic_year,exam_type)
            mycursor.execute(query_insert,val)

            db.commit()
            return redirect(url_for('admin_exam'))
            
        if 'addtimetable' in request.form:
            eid = request.form['exam_id']
            course = request.form['course']
            edate = request.form['exam_date']
            eday = request.form['exam-day']
            subject = request.form['subject']
            time = request.form['start-time'] + '-' + request.form['end-time']
            duration = request.form['duration']
            etype = request.form['exam-type']

            q1 = "INSERT INTO exam_timetable(EXAM_ID,COURSE,EXAM_DATE,EXAM_DAY,SUBJECT_NAME,EXAM_TIME,DURATION,EXAM_TYPE) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"
            val1 = (eid,course,edate,eday,subject,time,duration,etype)

            mycursor.execute(q1,val1)
            db.commit()
            # return redirect(url_for('admin_exam'))
    
    query = "SELECT * FROM exam ;"

    mycursor.execute(query)
    exams = mycursor.fetchall()
    # print(exams)

    for exam in exams:

        q2 = "SELECT * FROM exam_timetable WHERE EXAM_ID = %s ORDER BY exam_date ASC"

        mycursor.execute(q2,(exam['ID'],))
        exam['tt'] = mycursor.fetchall()
        # print(exam['tt'])


    # print(tt)
    return render_template('admin/admin_exam.html',courses=course , exams=exams , admin=admin,user_id=user_id)

@app.route('/admin/delete_exam/<int:id>')
def delete_exam(id):
    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("username")

    mycursor.execute("DELETE FROM exam WHERE ID=%s", (id,))
    db.commit()

    return render_template('/admin/admin_exam.html',admin=admin,user_id=user_id)

@app.route('/admin/delete_examtimetable/<int:id>',methods = ['GET','POST'])
def delete_examtimetable(id):
    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("username")

    # print(id)
    mycursor.execute("DELETE FROM exam_timetable WHERE id=%s", (id,))
    db.commit()
    # return redirect(url_for('admin_exam'))

    return render_template('/admin/admin_exam.html',admin=admin,user_id=user_id)


@app.route('/admin/time_table', methods=['GET', 'POST'])
def admin_time_table():

    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("username")

    course_query = "SELECT * FROM COURSES ;"
    mycursor.execute(course_query)
    course = mycursor.fetchall()

    timetable = []
    if 'generate' in request.form:
        course = request.form['course']
        day = request.form['day']
        lecture = request.form['lecture_name']
        start_time = request.form['start_time']
        end_time = request.form['end_time']
        subject_name = request.form['subject_name']
        teacher_name = request.form['teacher_name']

        query_insert = "INSERT INTO lecture_timetable (COURSE,LECTURE_DAY,PERIOD_NAME,START_TIME,END_TIME,SUBJECT_NAME,TEACHER_ID) VALUES (%s,%s,%s,%s,%s,%s,%s);"
        val = (course,day,lecture,start_time,end_time,subject_name,teacher_name)

        mycursor.execute(query_insert,val)
        db.commit()
    
    show_query = "SELECT * FROM lecture_timetable ;"
    mycursor.execute(show_query)
    timetable = mycursor.fetchall()
    # print(timetable)
    return render_template('admin/admin_timetable.html',courses=course,admin=admin, timetable=timetable,user_id=user_id)

@app.route('/admin/notice',methods=['GET','POST'])
def admin_notice():

    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("username")
    mycursor.execute("SELECT * FROM COURSES")
    courses = mycursor.fetchall()
    # print(courses)

    if request.method == "POST" :
        topic = request.form['topic']
        referance = "ADMIN"
        notice = request.form['notice']
        course = request.form['course']

        query = "INSERT INTO NOTICE (TOPIC,REFERANCE,NOTICE,COURSE) VALUES(%s,%s,%s,%s)"
        val = (topic,referance,notice,course)

        mycursor.execute(query,val)
        db.commit()
        return redirect(url_for('admin_notice'))
    mycursor.execute("SELECT * FROM NOTICE ORDER BY created_at DESC")
    notice = mycursor.fetchall()
    # print(notice)
    return render_template('admin/admin_notice.html',courses=courses,notice=notice,admin=admin,user_id=user_id)


@app.route('/admin/notice_delete/<int:id>')
def notice_delete(id):
    if session.get("role") != "admin" :
        return "access denied"

    user_id  = session.get("student_id")

    mycursor.execute("DELETE FROM notice WHERE id=%s", (id,))
    db.commit()
    # return redirect(url_for('admin_notice'))

    return render_template('/admin/admin_teachers.html',admin=admin,user_id=user_id)

#TEACHER ALL PAGES 

@app.route('/teacher')
def teacher():

    if session.get("role") != "teacher" :
        return "access denied"
    
    user_id  = session.get("teacher_id")
    firstname = session['firstname']
    # print(firstname)

    query = "SELECT * FROM TEACHERS WHERE ID = %s;"
    val = (user_id,)
    mycursor.execute(query, val)
    teacher = mycursor.fetchone()
    # print(teacher)
    return render_template('teacher/teacher_dashboard.html',teacher=teacher,firstname=firstname)
    
@app.route('/teacher/teacher_student', methods=['GET', 'POST'])
def teacher_student():

    if session.get("role") != "teacher":
        return "access denied"

    firstname = session.get('firstname')

    mycursor.execute("SELECT * FROM COURSES")
    courses = mycursor.fetchall()
    # print(courses)

    result = []
    selected_course = ""

    if request.method == 'POST':

        selected_course = request.form.get('course')

        if selected_course:

            show_query = "SELECT * FROM students WHERE COURSE = %s"

            mycursor.execute(show_query, (selected_course,))
            result = mycursor.fetchall()

    return render_template('teacher/students.html',courses=courses,result=result,firstname=firstname,selected_course=selected_course)


@app.route('/teacher/teacher_show_student/<int:id>')
def teacher_show_student(id):

    if session.get("role") != "teacher" :
        return "access denied"
    

    firstname = session.get('firstname')

    mycursor.execute("SELECT * FROM students WHERE id = %s", (id,))
    student = mycursor.fetchone()
    # print(student)
    return render_template('teacher/teacher_show_student.html', student=student,firstname=firstname)


@app.route('/teacher/teacher_exam')
def teacher_exam():
    if session.get("role") != "teacher" :
        return "access denied"
    
    firstname = session.get('firstname')

    query = "SELECT * FROM exam ORDER BY id DESC"

    mycursor.execute(query)
    exams = mycursor.fetchall()
    # print(exams)

    for exam in exams:

        q2 = "SELECT * FROM exam_timetable WHERE exam_id = %s ORDER BY exam_date ASC"

        mycursor.execute(q2, (exam['ID'],))
        exam['tt'] = mycursor.fetchall()
        # print(exam['tt'])

    return render_template('teacher/exam.html', exams=exams , tt=exam['tt'] ,firstname=firstname)

@app.route('/teacher/teacher_time_table')
def teacher_timetable():

    if session.get("role") != "teacher" :
        return "access denied"
    

    firstname = session.get('firstname')
    return render_template('teacher/timetable.html', firstname=firstname)



@app.route('/teacher/notice',methods=['GET','POST'])
def teacher_notice():

    if session.get("role") != "teacher" :
        return "access denied"

    firstname = session.get('firstname')

    
    mycursor.execute("SELECT * FROM COURSES")
    courses = mycursor.fetchall()
    # print(courses)

    if request.method == "POST" :
        topic = request.form['topic']
        referance = "TEACHER"
        notice = request.form['notice']
        course = request.form['course']

        query = "INSERT INTO NOTICE (TOPIC,REFERANCE,NOTICE,COURSE) VALUES(%s,%s,%s,%s)"
        val = (topic,referance,notice,course)

        mycursor.execute(query,val)
        db.commit()
        return redirect(url_for('teacher_notice'))
    
    mycursor.execute("SELECT * FROM NOTICE ORDER BY created_at DESC")
    notice = mycursor.fetchall()
    # print(notice)
    return render_template('teacher/notice.html',courses=courses,notice=notice,admin=admin,firstname=firstname)

    # return render_template('admin/admin_assignment.html',admin=admin)

@app.route('/teacher/notice_delete/<int:id>')
def teachernotice_delete(id):
    if session.get("role") != "teacher" :
        return "access denied"

    user_id  = session.get("student_id")

    mycursor.execute("DELETE FROM notice WHERE id=%s", (id,))
    db.commit()
    # return redirect(url_for('teacher_notice'))

    return render_template('/teacher/notice.html',admin=admin,user_id=user_id)


# STUDENT ALL PAGES 

@app.route('/student')
def student():

    if session.get("role") != "student" :
        return "access denied"

    firstname = session.get('firstname')

    user_id  = session.get("student_id")
    # print(user_id)
    query = "SELECT * FROM STUDENTS WHERE ID = %s;"
    val = (user_id,)
    mycursor.execute(query, val)
    student = mycursor.fetchone()

    # print(student)
    return render_template('student/student_dashboard.html',student=student,firstname=firstname)

@app.route('/student/exam')
def student_exam():
    
    firstname = session.get('firstname')
    course = session.get('course')
    # # print(clas,sec)
    query = "SELECT * FROM exam ;"

    mycursor.execute(query)
    exams = mycursor.fetchall()
    # print(exams)

    for exam in exams:

        q2 = "SELECT * FROM exam_timetable WHERE exam_id = %s AND COURSE=%s ORDER BY exam_date ASC"

        mycursor.execute(q2, (exam['ID'], course))
        exam['tt'] = mycursor.fetchall()
        # print(exam['tt'])

    return render_template('student/exam_student.html' , exams=exams ,tt=exam['tt'] ,firstname=firstname)
   
@app.route('/student/timetable')
def student_timetable():
    firstname = session.get('firstname')
    
    student_id = session.get("student_id")
    mycursor.execute("SELECT COURSE FROM students WHERE ID=%s",(student_id,))
    student = mycursor.fetchone()

    course = student['COURSE']

    mycursor.execute("SELECT * FROM lecture_timetable WHERE COURSE=%s ORDER BY FIELD (LECTURE_DAY,'MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY'),START_TIME ", (course,))

    timetable = mycursor.fetchall()
    print(timetable)

    return render_template('student/timetable_student.html',timetable=timetable,firstname=firstname)

@app.route('/student/notice')
def student_notice():

    if session.get("role") != "student" :
        return "access denied"
    
    firstname = session.get('firstname')
    course = session.get('course')
    print(course)

    query = "SELECT * FROM NOTICE WHERE COURSE=%s"
    val = (course,)
    mycursor.execute(query, val)
    notice = mycursor.fetchall()
    print(notice)
    return render_template('student/notice.html', notice=notice, firstname=firstname)

@app.route('/error')
def error():
    return render_template('error.html')


if __name__ == '__main__':
    app.run(debug=True)